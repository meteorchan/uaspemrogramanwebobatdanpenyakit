<x-layouts.app>
    <div class="container mx-auto">
        <div class="mt-10 flex justify-center items-center">
            <label class="z-10">
                <input type="text" class="px-4 py-3 rounded-full shadow-xl" placeholder="Search...">
            </label>
            <button class="z-10 ml-3 flex justify-center items-center rounded-full w-12 h-12 shadow-xl bg-blue-600 hover:bg-blue-800">
                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
            </button>
        </div>
        <div class="max-w-6xl mx-auto -mt-6">
            <div class="p-4 rounded-2xl border-2 border-gray-300">
                <div class="flex flex-row-reverse w-full">
                    <div class="min-w-fit flex justify-center items-center rounded-r-2xl p-8 bg-blue-600">
                        <img src="{{ Vite::asset('resources/img/obat-img.webp') }}" alt="">
                    </div>
                    <div class="max-w-full rounded-l-2xl p-10 bg-white">
                        <h3 class="mb-3 font-semibold text-gray-600">Cari berdasarkan abjad :</h3>
                        <div class="flex flex-wrap gap-3">
                            @foreach(range('A', 'Z') as $letter)
                                <button class="flex justify-center items-center w-10 h-10 rounded-lg bg-gray-200 hover:bg-gray-400 hover:text-white">
                                    <span>{{ $letter }}</span>
                                </button>
                            @endforeach
                        </div>
                        <div class="mt-8">
                            <ul>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">1. <a href="#" class="underline">Abacavier</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">2. <a href="#" class="underline">Abrocitinib</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">3. <a href="#" class="underline">Amoxicillin Indofarma/Kimia Farma</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">4. <a href="#" class="underline">Calcium D Redoxon (CDR)</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">5. <a href="#" class="underline">Ephedrine Tetes Hidung</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">6. <a href="#" class="underline">Fluticasone Inhalasi</a></li>
                                <li class="font-semibold my-3 text-gray-600 hover:text-gray-400">7. <a href="#" class="underline">Gentamicin Ophthalmic</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="py-10"></div>
    </div>
</x-layouts.app>
