<x-layouts.app x-data="information">
    <div class="container mx-auto">
        <div class="mt-10 flex justify-center items-center">
            <label class="z-10">
                <input x-model="search" @keyup.debounce="searchAction" type="text" class="px-4 py-3 rounded-full shadow-xl" placeholder="Search...">
            </label>
            <button @click="searchAction" class="z-10 ml-3 flex justify-center items-center rounded-full w-12 h-12 shadow-xl bg-blue-600 hover:bg-blue-800">
                <svg class="w-6 h-6 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
            </button>
        </div>
        <div class="max-w-6xl mx-auto -mt-6">
            <div class="p-4 rounded-2xl border-2 border-gray-300">
                <div class="flex flex-row-reverse w-full">
                    <div class="min-w-fit hidden lg:flex lg:justify-center lg:items-center rounded-r-2xl p-8 bg-blue-600">
                        <img src="{{ Vite::asset('resources/img/penyakit-img.webp') }}" alt="">
                    </div>
                    <div class="max-w-full flex flex-col rounded-2xl lg:rounded-r-none p-10 bg-white">
                        <h3 class="mb-3 font-semibold text-gray-600">Cari berdasarkan abjad :</h3>
                        <div class="flex flex-wrap gap-3">
                            @foreach(range('A', 'Z') as $letter)
                                <button @click="letterAction('{{ $letter }}')" :class="{'bg-gray-400 text-white': letter === '{{ $letter }}'}" class="flex justify-center items-center w-10 h-10 rounded-lg bg-gray-200 hover:bg-gray-400 hover:text-white">
                                    <span>{{ $letter }}</span>
                                </button>
                            @endforeach
                        </div>
                        <div class="mt-8 relative grow">
                            <div class="absolute right-1/2 bottom-1/2  transform translate-x-1/2 translate-y-1/2 " x-show="loading">
                                <div class="border-t-transparent border-solid animate-spin  rounded-full border-blue-400 border-8 h-12 w-12"></div>
                            </div>

                            <div x-show="loading === false && (data.length == 0 || loading !== false)" class="bg-gray-50 text-gray-500 text-center p-3 rounded-lg border">
                                Data tidak ditemukan...
                            </div>
                            <ul>
                                <template x-for="(item, index) in data">
                                    <li class="font-semibold my-3 text-gray-600 hover:text-gray-400"><span x-text="((page - 1) * 10) + index+1 + '. '"></span> <a :href="'{{ url('/') }}/' + item.type + '-' + item.slug" class="underline" x-text="item.name"></a></li>
                                </template>
                            </ul>
                        </div>

                        <div class="inline-flex items-center justify-center gap-3 mt-3" x-show="last_page !== 1">
                            <button @click="prevPage" :disabled="page === 1" class="inline-flex h-8 w-8 items-center justify-center rounded border border-gray-100 text-gray-900 hover:bg-blue-600 hover:text-white disabled:opacity-50 disabled:bg-gray-100 disabled:hover:bg-none disabled:hover:text-gray-900">
                                <span class="sr-only">Next Page</span>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                </svg>
                            </button>

                            <p class="text-xs text-gray-900">
                                <span x-text="page"></span>
                                <span class="mx-0.25">/</span>
                                <span x-text="last_page"></span>
                            </p>

                            <button @click="nextPage" :disabled="page === last_page" class="inline-flex h-8 w-8 items-center justify-center rounded border border-gray-100 text-gray-900 hover:bg-blue-600 hover:text-white disabled:opacity-50 disabled:bg-gray-100 disabled:hover:bg-none disabled:hover:text-gray-900">
                                <span class="sr-only">Next Page</span>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="py-5"></div>
    </div>

    @push('scripts')
        <script>
            document.addEventListener('alpine:init', () => {
                Alpine.data('information', () => ({
                    data: [],
                    page: 1,
                    from: null,
                    to: null,
                    last_page: null,
                    total: null,
                    letter: '',
                    search: '',
                    loading: false,
                    init() {
                        this.fetchData()
                    },
                    searchAction() {
                        this.data = []
                        this.letter = ''
                        this.page = 1
                        this.fetchData()
                    },
                    letterAction(letter) {
                        this.data = []
                        this.search = ''
                        this.page = 1

                        if (this.letter === letter) {
                            this.letter = ''
                        } else {
                            this.letter = letter
                        }

                        this.fetchData()
                    },
                    nextPage() {
                        if (this.page !== this.last_page) {
                            this.page += 1
                            this.fetchData()
                        }
                    },
                    prevPage() {
                        if (this.page !== 1) {
                            this.page -= 1
                            this.fetchData()
                        }
                    },
                    fetchData() {
                        this.loading = true
                        axios({
                            method: 'get',
                            url: '{{ route('obat-dan-penyakit') }}',
                            params: {
                                page: this.page,
                                letter: this.letter,
                                search: this.search
                            }
                        }).then(resp => {
                            this.data = resp.data.data
                            this.page = resp.data.current_page
                            this.from = resp.data.from
                            this.to = resp.data.to
                            this.last_page = resp.data.last_page
                            this.from = resp.data.from
                            this.total = resp.data.total
                        }).finally(() => this.loading = false)
                    }
                }))
            })
        </script>
    @endpush
</x-layouts.app>
