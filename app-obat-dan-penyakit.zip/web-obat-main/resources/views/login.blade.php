<x-layouts.app-base>
    <div class="login-page min-h-screen" x-data="{ showPassword: false }">
        <div class="relative">
            <img class="absolute top-4 right-4" src="{{ Vite::asset('resources/img/logo.png') }}" alt="">
        </div>
        <div class="flex flex-row px-6 pt-8 w-full">
            <div class="w-full max-w-md space-y-8 sm:p-8 rounded-lg">

                <form class="mt-16 w-full max-w-2xl" action="{{ route('login') }}" method="post">
                    @if (session('success'))
                    <div class="w-full" x-data="{show: true}">
                        <div class="bg-green-100 p-5 my-5 w-full rounded" x-show="show">
                            <div class="flex justify-between">
                                <div class="flex space-x-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="flex-none fill-current text-green-500 h-4 w-4">
                                        <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.25 16.518l-4.5-4.319 1.396-1.435 3.078 2.937 6.105-6.218 1.421 1.409-7.5 7.626z" /></svg>
                                    <div class="flex-1 leading-tight text-sm text-green-700 font-medium">{{ session('success') }}</div>
                                </div>
                                <button @click="show = false">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="flex-none fill-current text-green-600 h-3 w-3">
                                        <path d="M23.954 21.03l-9.184-9.095 9.092-9.174-2.832-2.807-9.09 9.179-9.176-9.088-2.81 2.81 9.186 9.105-9.095 9.184 2.81 2.81 9.112-9.192 9.18 9.1z" /></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    @endif

                    @csrf
                    <div class="mt-2">
                        <input type="email" name="email" id="email" autocomplete="given-email" class="block w-full rounded-lg border-0 p-3 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-600 shadow-md focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 @error('email') border-2 border-red-500 @enderror" placeholder="Enter Email" value="{{ old('email') }}" required>
                    </div>
                    <div class="mt-5 relative">
                        <input :type="showPassword ? 'text' : 'password'" name="password" id="password" autocomplete="given-password" class="block w-full rounded-lg border-0 p-3 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-600 shadow-md focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" required>
                        <div class="absolute top-3 right-3 cursor-pointer" @click="showPassword = !showPassword">
                            <svg x-show="!showPassword" class="w-5 h-5 text-gray-400 hover:text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                            </svg>
                            <svg x-show="showPassword" class="w-5 h-5 text-gray-400 hover:text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                                <path d="m10.79 12.912-1.614-1.615a3.5 3.5 0 0 1-4.474-4.474l-2.06-2.06C.938 6.278 0 8 0 8s3 5.5 8 5.5a7.029 7.029 0 0 0 2.79-.588M5.21 3.088A7.028 7.028 0 0 1 8 2.5c5 0 8 5.5 8 5.5s-.939 1.721-2.641 3.238l-2.062-2.062a3.5 3.5 0 0 0-4.474-4.474L5.21 3.089z"/>
                                <path d="M5.525 7.646a2.5 2.5 0 0 0 2.829 2.829l-2.83-2.829zm4.95.708-2.829-2.83a2.5 2.5 0 0 1 2.829 2.829zm3.171 6-12-12 .708-.708 12 12z"/>
                            </svg>
                        </div>
                    </div>
                    @error('email')
                        <div class="mt-3">
                            <span class="text-red-500 text-sm">The provided credentials do not match our records.</span>
                        </div>
                    @enderror
                    <div class="text-right mt-4 text-gray-400 hover:text-gray-600 text-sm">
                        <a href="{{ route('password.request') }}">Recover Password?</a>
                    </div>
                    <div class="mt-10">
                        <button type="submit" class="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-800 text-white font-semibold">Sign In</button>
                    </div>
                    <div class="mt-14">
                        <div class="w-full text-center border-b leading-[0.1em] mt-10 mr-0 mb-10">
                            <a href="{{ route('signup') }}" class="py-2 px-3 text-md bg-white text-gray-400">Sign Up</a>
                        </div>
                    </div>

                    <div class="mt-20 text-center z-10">
                        <a href="{{ route('admin.login') }}" class="text-sm text-blue-600 hover:text-blue-800">Admin click here</a>
                    </div>
                </form>
            </div>
            <div class="grow relative">
                <img class="max-w-xl absolute right-20" src="{{ Vite::asset('resources/img/orang_1.webp') }}" alt="">
            </div>
        </div>
    </div>
</x-layouts.app-base>
