<x-layouts.app-base>
    <div id="main-page" class="min-h-screen">
        <nav class="container mx-auto">
            <div class="px-3 py-3 lg:px-5 lg:pl-3">
                <div class="flex items-center justify-between">
                    <div class="flex items-center justify-start">
                        <a href="{{ route('home') }}">
                            <img class="w-16" src="{{ Vite::asset('resources/img/logo.png') }}" alt="">
                        </a>
                        <a href="{{ route('obat-dan-penyakit') }}" class="ml-5 text-white font-semibold">INFORMASI OBAT/PENYAKIT</a>
                    </div>
                    @auth
                        @if(request()->user()->is_admin)
                            <a href="{{ route('admin.dashboard') }}" class="py-2 px-5 rounded-full bg-blue-600 hover:bg-blue-800 text-white font-semibold">DASHBOARD</a>
                        @endif
                    @else
                        <a href="{{ route('login') }}" class="py-2 px-5 rounded-full bg-blue-600 hover:bg-blue-800 text-white font-semibold">LOGIN</a>
                    @endauth
                </div>
            </div>
        </nav>

        <main {{ $attributes }}>
            {{ $slot }}
        </main>
    </div>
</x-layouts.app-base>
