<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Admin</title>
    <link rel="shortcut icon" type="image/jpg" href="{{ Vite::asset('resources/img/favicon.ico') }}"/>

    @trixassets
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased flex">
<x-layouts.admin-sidebar/>
<div class="w-full flex flex-col h-screen overflow-y-hidden">
    <x-layouts.admin-header/>
    <div class="w-full overflow-x-hidden border-t flex flex-col">
        <main class="w-full flex-grow" {{ $attributes }}>
            {{ $slot }}
        </main>
    </div>
</div>

<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
@stack('scripts')
</body>
</html>
