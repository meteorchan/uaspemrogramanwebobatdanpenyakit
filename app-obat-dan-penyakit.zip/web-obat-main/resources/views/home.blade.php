<x-layouts.app>
    <div class="container mx-auto">
        <h1 class="mt-5 font-bold text-5xl text-center uppercase text-white">PRECISE AND ACCURATE</h1>
        <div class="flex justify-center mt-1">
            <div class="rounded-lg px-2 py-1 bg-blue-500">
                <h2 class="inline-block font-semibold text-2xl text-center text-white">Layanan Pencarian Obat dan Penyakit </h2>
            </div>
        </div>
        <div class="flex justify-center">
            <img class="max-w-2xl" src="{{ Vite::asset('resources/img/home-img.webp') }}" alt="">
        </div>
    </div>
</x-layouts.app>
