<x-layouts.admin x-data="{showModal: false, information: null}">
    <div id="bgMask" class="absolute z-0 top-0 right-0 w-full h-full bg-black opacity-50" x-show="showModal"></div>
    <div class="mt-10 px-6">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl text-gray-600">{{ $title }}</h1>
            <a href="{{ route($title === 'Obat' ? 'admin.obat-create' : 'admin.penyakit-create') }}" class="py-2 px-5 rounded-lg text-sm bg-blue-600 hover:bg-blue-800 text-white font-semibold">Tambah</a>
        </div>
        @if (session('success'))
            <div class="w-full" x-data="{show: true}">
                <div class="bg-green-100 p-5 my-5 w-full rounded" x-show="show">
                    <div class="flex justify-between">
                        <div class="flex space-x-3">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="flex-none fill-current text-green-500 h-4 w-4">
                                <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.25 16.518l-4.5-4.319 1.396-1.435 3.078 2.937 6.105-6.218 1.421 1.409-7.5 7.626z" /></svg>
                            <div class="flex-1 leading-tight text-sm text-green-700 font-medium">{{ session('success') }}</div>
                        </div>
                        <button @click="show = false">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="flex-none fill-current text-green-600 h-3 w-3">
                                <path d="M23.954 21.03l-9.184-9.095 9.092-9.174-2.832-2.807-9.09 9.179-9.176-9.088-2.81 2.81 9.186 9.105-9.095 9.184 2.81 2.81 9.112-9.192 9.18 9.1z" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        @endif
    </div>
    <div class="w-full">
        <table class="w-full table-auto">
            <thead>
            <tr class="border-b">
                <td class="text-lg text-gray-600 py-4 px-5 whitespace-nowrap">Nama {{ $title }}</td>
                <td class="text-lg text-gray-600 py-4 px-5">Deskripsi</td>
                <td class="text-lg text-gray-600 py-4 px-5 whitespace-nowrap"></td>
            </tr>
            </thead>
            <tbody>
            @foreach($information as $item)
                <tr class="border-b">
                    <td class="py-4 px-5 text-lg text-blue-600">{{ $item->name }}</td>
                    <td class="py-4 px-5 text-lg text-blue-600">
                        <div class="text-ellipsis">{{ Str::limit(strip_tags($item->trixRichText->first()->content), 80) }}</div>
                    </td>
                    <td class="py-4 px-5 text-lg text-blue-600">
                        <div class="flex items-center gap-3">
                            <button class="text-gray-600 hover:text-red-500" @click="showModal = !showModal; information = '{{ $item->slug }}'" @keydown.escape="showModal = false">
                                <svg class="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 20">
                                    <path d="M17 4h-4V2a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v2H1a1 1 0 0 0 0 2h1v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6h1a1 1 0 1 0 0-2ZM7 2h4v2H7V2Zm1 14a1 1 0 1 1-2 0V8a1 1 0 0 1 2 0v8Zm4 0a1 1 0 0 1-2 0V8a1 1 0 0 1 2 0v8Z"/>
                                </svg>
                            </button>
                            <a href="{{ route($item->type === 'obat' ? 'admin.obat-edit' : 'admin.penyakit-edit', $item->slug) }}" class="text-gray-600 hover:text-blue-600">
                                <svg class="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 18">
                                    <path d="M12.687 14.408a3.01 3.01 0 0 1-1.533.821l-3.566.713a3 3 0 0 1-3.53-3.53l.713-3.566a3.01 3.01 0 0 1 .821-1.533L10.905 2H2.167A2.169 2.169 0 0 0 0 4.167v11.666A2.169 2.169 0 0 0 2.167 18h11.666A2.169 2.169 0 0 0 16 15.833V11.1l-3.313 3.308Zm5.53-9.065.546-.546a2.518 2.518 0 0 0 0-3.56 2.576 2.576 0 0 0-3.559 0l-.547.547 3.56 3.56Z"/>
                                    <path d="M13.243 3.2 7.359 9.081a.5.5 0 0 0-.136.256L6.51 12.9a.5.5 0 0 0 .59.59l3.566-.713a.5.5 0 0 0 .255-.136L16.8 6.757 13.243 3.2Z"/>
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="px-6 py-5 block">
            {{ $information->links() }}
        </div>
    </div>

    <!-- Modal Delete -->
    <section id="modal" class="flex items-center justify-center absolute top-1/2 left-1/2">
        <div
            class="fixed z-50 max-w-xl bg-white md:rounded shadow-2xl"
            x-show="showModal"
            @click.away="showModal = false"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform scale-90"
            x-transition:enter-end="opacity-100 transform scale-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 transform scale-100"
            x-transition:leave-end="opacity-0 transform scale-90"
        >
            <form class="flex flex-col items-center p-6" x-bind:action="'{{ route('admin.information-store') }}' + '/' + information" method="post">
                @csrf
                @method('delete')
                <svg class="w-24 text-orange-400" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M7.938 2.016A.13.13 0 0 1 8.002 2a.13.13 0 0 1 .063.016.146.146 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.163.163 0 0 1-.054.06.116.116 0 0 1-.066.017H1.146a.115.115 0 0 1-.066-.017.163.163 0 0 1-.054-.06.176.176 0 0 1 .002-.183L7.884 2.073a.147.147 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566z"/>
                    <path d="M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0z"/>
                </svg>
                <span class="block mt-5 text-xl text-center">Apakah anda yakin akan menghapus data ini?</span>
                <div class="flex gap-3 mt-3">
                    <button type="submit" class="py-3 px-5 rounded bg-red-500 hover:bg-red-700 text-white">Hapus</button>
                    <button type="button" @click="showModal = false" class="py-3 px-5 rounded bg-gray-400 hover:bg-gray-700 text-white">Batal</button>
                </div>
            </form>
        </div>

    </section>
</x-layouts.admin>
