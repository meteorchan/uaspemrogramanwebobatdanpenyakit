<x-layouts.admin>
    <h1 class="ml-5 mt-6 text-2xl text-gray-600">User</h1>
    <table class="w-full mt-3">
        <thead>
        <tr class="border-b">
            <td class="text-lg text-gray-600 py-4 px-5">Nama Depan</td>
            <td class="text-lg text-gray-600 py-4 px-5">Nama Belakang</td>
            <td class="text-lg text-gray-600 py-4 px-5">Email</td>
        </tr>
        </thead>
        <tbody>
        @foreach($users as $user)
            <tr class="border-b">
                <td class="py-4 px-5 text-lg text-blue-600">{{ $user->first_name }}</td>
                <td class="py-4 px-5 text-lg text-blue-600">{{ $user->last_name }}</td>
                <td class="py-4 px-5 text-lg text-blue-600">{{ $user->email }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</x-layouts.admin>
