<x-layouts.admin>
    <form action="{{ isset($information) ? route('admin.information-update', $information->slug) : route('admin.information-store') }}" class="w-full p-6 mt-3" method="post">
        @if(isset($information)) @method('put') @endif
        @csrf
        <input type="hidden" name="type" value="{{ strtolower($title) }}">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl text-gray-600">{{ $title }}</h1>
            <button type="submit" class="py-2 px-5 rounded-lg text-sm bg-blue-600 hover:bg-blue-800 text-white font-semibold">Simpan</button>
        </div>
        <div class="w-full mt-5">
            <div class="flex flex-col mb-6">
                <label for="name" class="mb-3 text-gray-600">Nama {{ $title }}</label>
                <input type="text" id="name" name="name" class="max-w-md px-3 py-2 rounded border border-blue-500 focus-visible:outline-blue-600" value="{{ $information->name ?? old('name') }}" required>
            </div>
            <div class="flex flex-col mb-3">
                @if (isset($information))
                    {!! $information->trix('content') !!}
                @else
                    @trix(\App\Models\Information::class, 'content')
                @endif
            </div>
        </div>
    </form>

    @push('styles')
        <link rel="stylesheet" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
    @endpush

    @push('scripts')
        <script src="https://unpkg.com/trix@2.0.0/dist/trix.umd.min.js"></script>
    @endpush
</x-layouts.admin>
