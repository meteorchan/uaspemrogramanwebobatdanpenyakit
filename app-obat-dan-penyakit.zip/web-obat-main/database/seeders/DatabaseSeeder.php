<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
        \App\Models\User::insert([
            [
                'first_name' => 'Arnold',
                'last_name' => 'Yansen',
                'email' => 'theyansen@gmail.com',
                'password' => bcrypt('yansen123'),
            ],
            [
                'first_name' => 'Steven',
                'last_name' => 'Wijaya',
                'email' => 'stevwijayanjay@gmail.com',
                'password' => bcrypt('steven123'),
            ],
            [
                'first_name' => 'Tanisa',
                'last_name' => 'Humairoh',
                'email' => 'humaitans@gmail.com',
                'password' => bcrypt('tanisa123'),
            ],
        ]);
    }
}
