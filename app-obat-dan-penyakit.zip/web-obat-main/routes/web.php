<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PasswordController;
use App\Http\Controllers\InformationController;
use App\Http\Controllers\SignUpController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::view('/', 'home')->name('home');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'login'])->name('login');
    Route::post('/login', [AuthController::class, 'authenticate']);
    Route::get('/signup', [SignUpController::class, 'index'])->name('signup');
    Route::post('/signup', [SignUpController::class, 'signUp']);
    Route::get('/forgot-password', [PasswordController::class, 'showForgotPage'])->name('password.request');
    Route::post('/forgot-password', [PasswordController::class, 'sendResetLinkEmail']);
    Route::get('/reset-password/{token}', [PasswordController::class, 'showResetPage'])->name('password.reset');
    Route::post('/reset-password', [PasswordController::class, 'reset'])->name('password.update');

    Route::get('/admin/login', [Admin\AuthController::class, 'login'])->name('admin.login');
    Route::post('/admin/login', [Admin\AuthController::class, 'authenticate']);
});

Route::middleware('auth')->group(function () {
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/obat-dan-penyakit', [InformationController::class, 'index'])->name('obat-dan-penyakit');
    Route::get('/obat-{information:slug}', [InformationController::class, 'show']);
    Route::get('/penyakit-{information:slug}', [InformationController::class, 'show']);
});

Route::middleware(['auth', 'admin'])
    ->prefix('admin')
    ->name('admin.')->group(function () {
        Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');
        Route::get('/user', [Admin\UserController::class, 'index'])->name('user');

        Route::get('/obat', [Admin\InformationController::class, 'indexObat'])->name('obat');
        Route::get('/obat/create', [Admin\InformationController::class, 'createObat'])->name('obat-create');
        Route::get('/obat/{information:slug}', [Admin\InformationController::class, 'editObat'])->name('obat-edit');

        Route::get('/penyakit', [Admin\InformationController::class, 'indexPenyakit'])->name('penyakit');
        Route::get('/penyakit/create', [Admin\InformationController::class, 'createPenyakit'])->name('penyakit-create');
        Route::get('/penyakit/{information:slug}', [Admin\InformationController::class, 'editPenyakit'])->name('penyakit-edit');

        // store, update, destroy information of obat and penyakit
        Route::post('/informasi', [Admin\InformationController::class, 'store'])->name('information-store');
        Route::put('/informasi/{information:slug}', [Admin\InformationController::class, 'update'])->name('information-update');
        Route::delete('/informasi/{information:slug}', [Admin\InformationController::class, 'destroy'])->name('information-destroy');
    });
