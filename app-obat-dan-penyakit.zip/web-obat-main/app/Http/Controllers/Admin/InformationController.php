<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Information;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class InformationController extends Controller
{
    private function generateSlug(string $name): string
    {
        $slug = Str::slug($name);
        $random_str = '';
        while (true) {
            $slug .= $random_str;
            $exists_information = Information::where('slug', $slug)->first();
            if (!$exists_information) {
                break;
            }

            $random_str = Str::random(10);
        }

        return $slug;
    }

    public function indexObat()
    {
        $title = 'Obat';
        $information = Information::with('trixRichText')->where('type', 'obat')->paginate(10);

        return view('admin.information', compact('title', 'information'));
    }

    public function createObat()
    {
        $title = 'Obat';
        return view('admin.information-form', compact('title'));
    }

    public function editObat(Information $information)
    {
        $title = 'Obat';
        return view('admin.information-form', compact('title', 'information'));
    }

    public function indexPenyakit()
    {
        $title = 'Penyakit';
        $information = Information::with('trixRichText')->where('type', 'penyakit')->paginate(10);

        return view('admin.information', compact('title', 'information'));
    }

    public function createPenyakit()
    {
        $title = 'Penyakit';
        return view('admin.information-form', compact('title'));
    }

    public function editPenyakit(Information $information)
    {
        $title = 'Penyakit';
        return view('admin.information-form', compact('title', 'information'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'type' => 'required',
            'name' => 'required',
            'information-trixFields' => 'required',
            'attachment-information-trixFields' => 'nullable',
        ]);

        $data['slug'] = $this->generateSlug($data['name']);
        Information::create($data);

        $route = $data['type'] === 'obat' ? 'admin.obat' : 'admin.penyakit';
        return redirect()
            ->route($route)
            ->with('success', 'Berhasil menambahkan data ' . $data['type']);
    }

    public function update(Information $information, Request $request)
    {
        $data = $request->validate([
            'name' => 'required',
            'information-trixFields' => 'required',
            'attachment-information-trixFields' => 'nullable',
        ]);

        if ($information->name !== $data['name']) {
            $data['slug'] = $this->generateSlug($data['name']);
        }

        $information->update($data);
        $route = $information->type === 'obat' ? 'admin.obat' : 'admin.penyakit';
        return redirect()
            ->route($route)
            ->with('success', 'Berhasil mengubah data ' . $information->type);
    }

    public function destroy(Information $information)
    {
        $type = $information->type;
        $information->trixRichText()->delete();
        $information->trixAttachments()->delete();
        $information->delete();

        $route = $type === 'obat' ? 'admin.obat' : 'admin.penyakit';
        return redirect()
            ->route($route)
            ->with('success', 'Berhasil menghapus data ' . $type);
    }
}
