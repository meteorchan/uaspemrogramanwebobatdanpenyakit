<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Information;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $user = User::query()->count();
        $obat = Information::query()->where('type', 'obat')->count();
        $penyakit = Information::query()->where('type', 'penyakit')->count();

        return view('admin.dashboard', compact('user', 'obat', 'penyakit'));
    }
}
