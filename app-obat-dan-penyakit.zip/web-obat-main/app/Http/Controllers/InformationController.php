<?php

namespace App\Http\Controllers;

use App\Models\Information;
use Illuminate\Http\Request;

class InformationController extends Controller
{
    public function index(Request $request)
    {
        if ($request->wantsJson()) {
            $query = Information::query()
                ->select('name', 'slug', 'type');

            if ($request->get('letter')) {
                $query = $query->where('name', 'like', $request->get('letter') . '%');
            }

            if ($request->get('search')) {
                $query = $query->where('name', 'like', '%' . $request->get('search') . '%');
            }

            $data = $query->orderBy('name')->paginate(10);

            return response()->json($data, 200, [
                'Cache-Control' => ['private', 'max-age=30']
            ]);
        }

        return view('informasi');
    }

    public function show(Information $information)
    {
        return view('informasi-detail', compact('information'));
    }
}
