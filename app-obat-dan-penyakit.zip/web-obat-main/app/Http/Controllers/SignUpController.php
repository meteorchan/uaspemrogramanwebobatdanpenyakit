<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Notifications\RegistrationNotification;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class SignUpController extends Controller
{
    public function index(): View
    {
        return view('register');
    }

    public function signUp(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'first_name' => ['required'],
            'last_name' => ['required'],
            'email' => ['required', 'email', 'unique:users'],
            'password' => ['required', 'min:8'],
        ]);

        $credentials['password'] = bcrypt($credentials['password']);

        /** @var User $user */
        $user = User::create($credentials);
        $user->notify(new RegistrationNotification($user));

        return redirect()
            ->route('login')
            ->with('success', 'Registrasi akun berhasil. Login akun anda untuk melanjutkan.');
    }
}
