<?php

namespace App\Console\Commands;

use App\Models\Information;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class ScrapeData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:scrape-data {type}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Scrape Data From alodokter.com';

    protected string $base_url = 'https://www.alodokter.com';

    private function getData($type)
    {
        $json = file_get_contents(storage_path($type . '.json'));
        return json_decode($json, true);
    }

    private function scrape($path)
    {
        $url = $this->base_url . '/' . $path;
        $response = Http::get($url);
        if ($response->status() !== 200) {
            throw new \Error("Error fetch {$url}, status: {$response->status()}.");
        }

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        $dom->loadHTML($response->body());
        $xpath = new \DOMXPath($dom);

        $content = '';

        $items = $xpath->evaluate('//div[@id="postContent"]');
        foreach ($items as $item) {
            foreach ($item->childNodes as $child) {
                $content .= trim($dom->saveHTML($child));
            }
        }

        return $content;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $type = $this->argument('type');

        if (!in_array($type, ['obat', 'penyakit'], true)) {
            $this->error("Invalid type, only 'obat' and 'penyakit'");
            return 1;
        }

        $data = $this->getData($type);
        $data_count = count($data);

        foreach ($data as $idx => $item) {
            $idx += 1;
            $this->info("Processing {$idx} of {$data_count}.");
            $content = $this->scrape($item['permalink']);

            Information::create([
                'type' => $type,
                'name' => $item['post_title'],
                'slug' => $item['permalink'],
                'information-trixFields' => ['content' => $content],
//                'attachment-information-trixFields' => ['content' => ''],
            ]);
        }
    }
}
